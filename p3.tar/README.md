# CPSC 3500 Project 3

> **Date:** February 18th, 2022

> **Assignment:** https://seattleu.instructure.com/courses/1601766/assignments/6998814

## Team members and contribution

- Gary Tou ([@garyhtou](https://github.com/garyhtou))
- Castel Villalobos ([@impropernoun](https://github.com/impropernoun))
- Hank Rudolph ([@hankrud](https://github.com/HankRud))
